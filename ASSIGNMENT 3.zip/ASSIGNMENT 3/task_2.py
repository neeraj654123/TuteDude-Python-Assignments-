import math

num =int(input("Enter a no.: "))

print(f"Square root: {math.sqrt(num)}")
print(f"Logarithm: {math.log(num)}")
print(f"Sine :{math.sin(num)}")