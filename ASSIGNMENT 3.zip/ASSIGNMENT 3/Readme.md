<!-- Assignment-3 -->

<!-- Task-1 -->

<!-- In task_1.py,we define a function nameed as factorial.Using this function we can find factorial of a number.
If entered number is is 0 or1 the result is 1 and if input is lessthan 0 it will print Enter valid input.
If Entered input is valid, then it will return factorial of no. by recursion
 -->

<!-- Task-2 -->

<!-- In task_2.py,At first, we import math module. Then we take input from the user as num.
Then we print the result of Square root, Log, Sine of num  -->
